param(
  [int]$Port = 5173,
  [string]$AppPath = $PSScriptRoot
)

$ErrorActionPreference = 'Stop'
Set-Location $AppPath

if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  Write-Host 'Node.js chua duoc cai. Hay cai Node.js LTS truoc: https://nodejs.org/' -ForegroundColor Red
  exit 1
}

if (-not (Get-Command serve -ErrorAction SilentlyContinue)) {
  npm install -g serve
}

Write-Host "SEO Ops dang chay tai http://0.0.0.0:$Port"
serve -s $AppPath -l "tcp://0.0.0.0:$Port"
